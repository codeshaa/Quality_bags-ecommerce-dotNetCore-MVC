﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace QualityBags.Models
{
    public class Supplier
    {
        [Key]
        public int SupplierID { get; set; }

        [Display(Name = "Supplier Name")]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Category name must be at least 2 characters and not more than 30")]
        public string SupplierName { get; set; }

        [Required]
        [Display(Name = "Supplier Email")]
        [DataType(DataType.EmailAddress)]
        public string SupplierEmail { get; set; }

        [Display(Name = "Supplier Address")]
        [StringLength(60, MinimumLength = 3, ErrorMessage = "Category name must be at least 3 characters and not more than 50")]
        public string SupplierAddress { get; set; }

        [Display(Name = "Phone (Work)")]
        [DataType(DataType.PhoneNumber)]
        public string SupplierPhoneWork { get; set; }

        [Display(Name = "Phone (Mobile)")]
        [DataType(DataType.PhoneNumber)]
        public string SupplierPhoneMobile { get; set; }

        [Display(Name = "Phone (Home)")]
        [DataType(DataType.PhoneNumber)]
        public string SupplierPhoneHome { get; set; }


        public ICollection<BagItem> BagItem { get; set; }
    }
}

