﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace QualityBags.Models
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
        [Display(Name = "Address")]
        public String Address { get; set; }

        [Display(Name = "Last Name")]
        public String LastName { get; set; }

        [Display(Name = "First Name")]
        public String FirstName { get; set; }

        [Display(Name = "Middle Name")]
        public String MidName { get; set; }

        [Display(Name = "Home Phone")]
        public String HomePhone { get; set; }

        [Display(Name = "Mobile Phone")]
        public String MobilePhone { get; set; }

        public bool Enabled { get; set; }

        [Display(Name = "Name")]
        public String FullName
        {
            get
            {
                return LastName + ", " + FirstName + " " + MidName;
            }
        }
    }
}
