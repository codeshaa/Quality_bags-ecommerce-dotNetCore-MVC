﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QualityBags.Models
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; }

        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Display(Name = "Middle Name")]
        public string MidName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Display(Name = "City")]
        public string City { get; set; }

        [Display(Name = "State")]
        public string State { get; set; }

        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }

        [Display(Name = "Country")]
        public string Country { get; set; }

        [Display(Name = "Phone")]
        public string Phone { get; set; }

        [Display(Name = "Status")]
        public OrderStatus Status { get; set; }

        [Display(Name = "Grand Total")]
        [DataType(DataType.Currency)]
        public decimal Total { get; set; }

        [Display(Name = "GST Included")]
        [DataType(DataType.Currency)]
        public decimal GST { get; set; }

        [Display(Name = "Order Date")]
        public DateTime OrderDate { get; set; }

        public enum OrderStatus
        {
            Pending,
            Shipped
        }

        public List<OrderDetail> OrderDetails { get; set; }
        public ApplicationUser User { get; set; }
    }
}
