﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace QualityBags.Models
{
    public class Category
    {   
        [Key]
        public int CategoryID { get; set; }

        [Display(Name = "Category Name")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Category name must contain at least 3 characters and maximum 30")]
        public string CategoryName { get; set; }

        [Display(Name = "Category Description")]
        public string CategoryDescription { get; set; }

        public ICollection<BagItem> BagItem { get; set; }
    }
}
