﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace QualityBags.Models
{
    public class BagItem
    {
        [Key]
        public int ID { get; set; }

        [Display(Name = "Bag Name")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Category name must be at least 3 characters and not more than 30")]
        public string BagName { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        [StringLength(50, MinimumLength = 5, ErrorMessage = "Category name must be at least 5 characters and not more than 50")]
        public string Description { get; set; }

        public string ImageURL { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Display(Name = "Added Date")]
        public DateTime AddedDate { get; set; }

        public int CategoryID { get; set; }
        public int SupplierID { get; set; }

        public Category Category { get; set; }
        public Supplier Supplier { get; set; }

    }
}
