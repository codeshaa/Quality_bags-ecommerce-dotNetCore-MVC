using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using QualityBags.Data;
using QualityBags.Models;
using Microsoft.AspNetCore.Authorization;

namespace QualityBags.Controllers
{
    [AllowAnonymous]
    [Authorize(Roles = "Member")]
    public class MemberBagItemsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MemberBagItemsController(ApplicationDbContext context)
        {
            _context = context;    
        }

        // GET: MemberBagItems
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["PriceSortParm"] = sortOrder == "Price" ? "price_desc" : "Price";
            ViewData["DescriptionSortParm"] = sortOrder == "Description" ? "description_desc" : "Description";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";
            ViewData["CategorySortParm"] = sortOrder == "Category" ? "category_desc" : "Category";
            ViewData["SupplierSortParm"] = sortOrder == "Supplier" ? "supplier_desc" : "Supplier";
            ViewData["CurrentSort"] = sortOrder;
            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["CurrentFilter"] = searchString;
            var bagItems = from c in _context.BagItems.Include(b => b.Supplier).Include(b => b.Category)
                           select c;
            if (!String.IsNullOrEmpty(searchString))
            {
                bagItems = bagItems.Where(c => c.BagName.Contains(searchString) || c.Description.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    bagItems = bagItems.OrderByDescending(s => s.BagName);
                    break;
                case "Price":
                    bagItems = bagItems.OrderBy(s => s.Price);
                    break;
                case "price_desc":
                    bagItems = bagItems.OrderByDescending(s => s.Price);
                    break;
                case "description_desc":
                    bagItems = bagItems.OrderByDescending(s => s.Description);
                    break;
                case "Description":
                    bagItems = bagItems.OrderBy(s => s.Description);
                    break;
                case "Date":
                    bagItems = bagItems.OrderBy(s => s.AddedDate);
                    break;
                case "date_desc":
                    bagItems = bagItems.OrderByDescending(s => s.AddedDate);
                    break;
                case "Category":
                    bagItems = bagItems.OrderBy(s => s.Category.CategoryName);
                    break;
                case "category_desc":
                    bagItems = bagItems.OrderByDescending(s => s.Category.CategoryName);
                    break;
                case "Supplier":
                    bagItems = bagItems.OrderBy(s => s.Supplier.SupplierName);
                    break;
                case "supplier_desc":
                    bagItems = bagItems.OrderByDescending(s => s.Supplier.SupplierName);
                    break;
                default:
                    bagItems = bagItems.OrderBy(s => s.BagName);
                    break;
            }

            int pageSize = 10;
            return View(await PaginatedList<BagItem>.CreateAsync(bagItems.AsNoTracking(), page ?? 1, pageSize));
        }

        // GET: MemberBagItems/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bagItem = await _context.BagItems
                .Include(b => b.Category)
                .Include(b => b.Supplier)
                .AsNoTracking()
                .SingleOrDefaultAsync(m => m.ID == id);
            if (bagItem == null)
            {
                return NotFound();
            }

            return View(bagItem);
        }
    }
}
