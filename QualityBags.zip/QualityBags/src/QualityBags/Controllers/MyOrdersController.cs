using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using QualityBags.Data;
using QualityBags.Models;
using Microsoft.AspNetCore.Authorization;

namespace QualityBags.Controllers
{
    [Authorize(Roles = "Member")]
    public class MyOrdersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MyOrdersController(ApplicationDbContext context)
        {
            _context = context;    
        }

        // GET: MyOrders
        public async Task<IActionResult> Index()
        {
            var currentUserName = User.Identity.Name;
            var orders = from o in _context.Orders.Include(i => i.User) select o;

            if (!String.IsNullOrEmpty(currentUserName))
            {
                orders = orders.Where(o => o.User.UserName.Contains(currentUserName));
            }

            return View(await orders.AsNoTracking().ToListAsync());
        }
    }
}
