using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using QualityBags.Data;
using QualityBags.Models;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Collections.Generic;
using System;
using Microsoft.AspNetCore.Authorization;

namespace QualityBags.Controllers
{
    [Authorize(Roles = "Admin")]
    public class BagItemsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IHostingEnvironment _hostingEnv;

        public BagItemsController(ApplicationDbContext context, IHostingEnvironment hEnv)
        {
            _context = context;
            _hostingEnv = hEnv;
        }

        // GET: BagItems
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["PriceSortParm"] = sortOrder == "Price" ? "price_desc" : "Price";
            ViewData["DescriptionSortParm"] = sortOrder == "Description" ? "description_desc" : "Description";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";
            ViewData["CategorySortParm"] = sortOrder == "Category" ? "category_desc" : "Category";
            ViewData["SupplierSortParm"] = sortOrder == "Supplier" ? "supplier_desc" : "Supplier";
            ViewData["CurrentSort"] = sortOrder;
            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["CurrentFilter"] = searchString;
            var bagItems = from c in _context.BagItems.Include(b => b.Supplier).Include(b => b.Category)
                           select c;
            if (!String.IsNullOrEmpty(searchString))
            {
                bagItems = bagItems.Where(c => c.BagName.Contains(searchString) || c.Description.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    bagItems = bagItems.OrderByDescending(s => s.BagName);
                    break;
                case "Price":
                    bagItems = bagItems.OrderBy(s => s.Price);
                    break;
                case "price_desc":
                    bagItems = bagItems.OrderByDescending(s => s.Price);
                    break;
                case "description_desc":
                    bagItems = bagItems.OrderByDescending(s => s.Description);
                    break;
                case "Description":
                    bagItems = bagItems.OrderBy(s => s.Description);
                    break;
                case "Date":
                    bagItems = bagItems.OrderBy(s => s.AddedDate);
                    break;
                case "date_desc":
                    bagItems = bagItems.OrderByDescending(s => s.AddedDate);
                    break;
                case "Category":
                    bagItems = bagItems.OrderBy(s => s.Category.CategoryName);
                    break;
                case "category_desc":
                    bagItems = bagItems.OrderByDescending(s => s.Category.CategoryName);
                    break;
                case "Supplier":
                    bagItems = bagItems.OrderBy(s => s.Supplier.SupplierName);
                    break;
                case "supplier_desc":
                    bagItems = bagItems.OrderByDescending(s => s.Supplier.SupplierName);
                    break;
                default:
                    bagItems = bagItems.OrderBy(s => s.BagName);
                    break;
            }

            int pageSize = 10;
            return View(await PaginatedList<BagItem>.CreateAsync(bagItems.AsNoTracking(), page ?? 1, pageSize));
        }

        // GET: BagItems/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bagItem = await _context.BagItems
                .Include(b => b.Category)
                .Include(b => b.Supplier)
                .AsNoTracking()
                .SingleOrDefaultAsync(m => m.ID == id);
            if (bagItem == null)
            {
                return NotFound();
            }

            return View(bagItem);
        }

        // GET: BagItems/Create
        public IActionResult Create()
        {
            PopulateCategoryDropDownList();
            PopulateSupplierDropDownList();
            return View();
        }

        // POST: BagItems/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BagName,Price,Description,CategoryID,SupplierID")] BagItem bagItem, IList<IFormFile> _files)
        {
            var relativeName = "";
            var fileName = "";

            if (_files.Count < 1)
            {
                relativeName = "/images/products/default.jpg";
            }
            else
            {
                foreach (var file in _files)
                {
                    fileName = ContentDispositionHeaderValue
                                      .Parse(file.ContentDisposition)
                                      .FileName
                                      .Trim('"');
                    //Path for localhost
                    fileName = Path.GetFileName(fileName);
                    relativeName = "/images/products/" + DateTime.Now.ToString("ddMMyyyy_HHmmssffffff") + fileName;

                    using (FileStream fs = System.IO.File.Create(_hostingEnv.WebRootPath + relativeName))
                    {
                        await file.CopyToAsync(fs);
                        fs.Flush();
                    }
                }
            }
            bagItem.ImageURL = relativeName;
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(bagItem);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            catch (DbUpdateException /* ex */)
            {
                //Log the error (uncomment ex variable name and write a log.
                ModelState.AddModelError("", "Unable to save changes. " + "Try again, and if the problem persists " + "see your system administrator.");
            }
            PopulateCategoryDropDownList(bagItem.CategoryID);
            PopulateSupplierDropDownList(bagItem.SupplierID);
            return View(bagItem);
        }

        // GET: BagItems/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bagItem = await _context.BagItems.AsNoTracking().SingleOrDefaultAsync(m => m.ID == id);
            if (bagItem == null)
            {
                return NotFound();
            }
            PopulateCategoryDropDownList(bagItem.CategoryID);
            PopulateSupplierDropDownList(bagItem.SupplierID);
            return View(bagItem);
        }

        // POST: BagItems/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditPost(int? id, IList<IFormFile> _files)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bagsToUpdate = await _context.BagItems
                .SingleOrDefaultAsync(c => c.ID == id);

            var relativeName = "";
            var fileName = "";

            if (_files.Count < 1)
            {
                relativeName = "/images/products/default.jpg";
            }
            else
            {
                foreach (var file in _files)
                {
                    fileName = ContentDispositionHeaderValue
                                      .Parse(file.ContentDisposition)
                                      .FileName
                                      .Trim('"');
                    //Path for localhost
                    fileName = Path.GetFileName(fileName);
                    relativeName = "/images/products/" + DateTime.Now.ToString("ddMMyyyy_HHmmssffffff") + fileName;

                    using (FileStream fs = System.IO.File.Create(_hostingEnv.WebRootPath + relativeName))
                    {
                        await file.CopyToAsync(fs);
                        fs.Flush();
                    }
                }
            }
            bagsToUpdate.ImageURL = relativeName;


            if (await TryUpdateModelAsync<BagItem>(bagsToUpdate, "",
                 b => b.BagName, b => b.Price, b => b.Description, b => b.AddedDate, b => b.CategoryID, b => b.SupplierID))
            {
                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    //Log the error (uncomment ex variable name and write a log.)
                    ModelState.AddModelError("", "Unable to save changes. " +
                    "Try again, and if the problem persists, " +
                    "see your system administrator.");
                }
                return RedirectToAction("Index");
            }
            PopulateCategoryDropDownList(bagsToUpdate.CategoryID);
            PopulateSupplierDropDownList(bagsToUpdate.SupplierID);
            return View(bagsToUpdate);
        }

        private void PopulateCategoryDropDownList(object selectedCategory = null)
        {
            var categoriesQuery = from d in _context.Categories
                                  orderby d.CategoryName
                                  select d;
            ViewBag.CategoryID = new SelectList(categoriesQuery.AsNoTracking(), "CategoryID", "CategoryName", selectedCategory);
        }

        private void PopulateSupplierDropDownList(object selectedSupplier = null)
        {
            var suppliersQuery = from d in _context.Suppliers
                                 orderby d.SupplierName
                                 select d;
            ViewBag.SupplierID = new SelectList(suppliersQuery.AsNoTracking(), "SupplierID", "SupplierName", selectedSupplier);
        }


        // GET: BagItems/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bagItem = await _context.BagItems
                .Include(b => b.Category)
                .Include(b => b.Supplier)
                .AsNoTracking()
                .SingleOrDefaultAsync(m => m.ID == id);
            if (bagItem == null)
            {
                return NotFound();
            }

            return View(bagItem);
        }

        // POST: BagItems/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bagItem = await _context.BagItems.SingleOrDefaultAsync(m => m.ID == id);
            _context.BagItems.Remove(bagItem);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException /* s */)
            {
                TempData["BagItemUsed"] = "The Bag item being deleted has been used in previous orders. Delete those orders before trying again.";
                return RedirectToAction("Delete");
            }

            return RedirectToAction("Index");
        }

        private bool BagItemExists(int id)
        {
            return _context.BagItems.Any(e => e.ID == id);
        }
    }
}
