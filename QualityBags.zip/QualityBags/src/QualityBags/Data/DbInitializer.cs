﻿using QualityBags.Models;
using System;
using System.Linq;
namespace QualityBags.Data
{
    public static class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            //Looking for any Bag Items.
            if (context.BagItems.Any())
            {
                return;   // DB has been seeded
            }

            var category = new Category[]
            {
            new Category{CategoryName="Men's Bag", CategoryDescription="Bags for men"},
            new Category{CategoryName="Women's Bag", CategoryDescription="Bags for Women"},
            new Category{CategoryName="Children's Bag", CategoryDescription="Bags for Childrens"},
            new Category{CategoryName="Backpack", CategoryDescription="Backpack for tourists"}
            };
            foreach (Category c in category)
            {
                context.Categories.Add(c);
            }
            context.SaveChanges();

            var suppliers = new Supplier[]
            {
            new Supplier{SupplierName="Reebok Bags", SupplierAddress="48 Kitechner Street", SupplierEmail="sales@rebook.co.nz", SupplierPhoneWork="0225344352", SupplierPhoneMobile="0237861863"},
            new Supplier{SupplierName="Carleton", SupplierAddress="48 Kitechner Street", SupplierEmail="info@carlton.com", SupplierPhoneMobile="0222384100"},
            new Supplier{SupplierName="LeatherWorks", SupplierAddress="48 Kitechner Street", SupplierEmail="sales@leatherworks.co.nz", SupplierPhoneWork="0222644492", SupplierPhoneMobile="0271862965", SupplierPhoneHome="228762875"},
            new Supplier{SupplierName="Camp Man", SupplierAddress="48 Kitechner Street", SupplierEmail="sales@campman.co.nz", SupplierPhoneHome="0222344395"}
            };
            foreach (Supplier s in suppliers)
            {
                context.Suppliers.Add(s);
            }
            context.SaveChanges();

            var bagitem = new BagItem[]
            {
            new BagItem{BagName="Carson",Price=20,Description= "Simple and Beautiful", AddedDate = DateTime.Parse("2017-04-01"), ImageURL="/images/products/bag1.jpg",
                CategoryID = category.Single(c => c.CategoryName == "Men's Bag").CategoryID, SupplierID = suppliers.Single(s => s.SupplierName == "Reebok Bags").SupplierID},
            new BagItem{BagName="Revlet",Price=33,Description= "Amazing craft", AddedDate = DateTime.Parse("2017-04-02"), ImageURL="/images/products/bag2.jpg",
                CategoryID = category.Single(c => c.CategoryName == "Men's Bag").CategoryID, SupplierID = suppliers.Single(s => s.SupplierName == "Carleton").SupplierID},
            new BagItem{BagName="Orlon",Price=19,Description= "Elegance with beaty", AddedDate = DateTime.Parse("2017-04-02"), ImageURL="/images/products/bag3.jpg",
                CategoryID = category.Single(c => c.CategoryName == "Women's Bag").CategoryID, SupplierID = suppliers.Single(s => s.SupplierName == "LeatherWorks").SupplierID},
            new BagItem{BagName="Revo",Price=16,Description= "Tailored for youth", AddedDate = DateTime.Parse("2017-04-03"), ImageURL="/images/products/bag4.jpg",
                CategoryID = category.Single(c => c.CategoryName == "Backpack").CategoryID, SupplierID = suppliers.Single(s => s.SupplierName == "Reebok Bags").SupplierID},
            new BagItem{BagName="Amate",Price=24,Description= "Carefully crafted", AddedDate = DateTime.Parse("2017-04-04"), ImageURL="/images/products/bag5.jpg",
                 CategoryID = category.Single(c => c.CategoryName == "Children's Bag").CategoryID, SupplierID = suppliers.Single(s => s.SupplierName == "Carleton").SupplierID},
            new BagItem{BagName="Sharlton",Price=28,Description= "Strong and secure", AddedDate = DateTime.Parse("2017-04-02"), ImageURL="/images/products/bag6.jpg",
                CategoryID = category.Single(c => c.CategoryName == "Backpack").CategoryID, SupplierID = suppliers.Single(s => s.SupplierName == "LeatherWorks").SupplierID},
            new BagItem{BagName="FeathR",Price=30,Description= "Simple and soft", AddedDate = DateTime.Parse("2017-04-03"), ImageURL="/images/products/bag7.jpg",
                CategoryID = category.Single(c => c.CategoryName == "Women's Bag").CategoryID, SupplierID = suppliers.Single(s => s.SupplierName == "Camp Man").SupplierID},
            new BagItem{BagName="Attract",Price=24,Description= "Beautiful and creative", AddedDate = DateTime.Parse("2017-03-29"), ImageURL="/images/product/bag8.jpg",
                CategoryID = category.Single(c => c.CategoryName == "Children's Bag").CategoryID, SupplierID = suppliers.Single(s => s.SupplierName == "Carleton").SupplierID}
            };
            foreach (BagItem b in bagitem)
            {
                context.BagItems.Add(b);
            }
            context.SaveChanges();
        }
    }
}